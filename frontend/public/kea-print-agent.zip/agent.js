/**
 * Kea By The Pool - Reliable Multi-Printer KOT Agent
 *
 * Run this process on the restaurant desktop connected to the same LAN as the
 * thermal printers. The cloud backend stores/streams KOT jobs; this local agent
 * is responsible for USB and private-LAN TCP/9100 delivery.
 *
 * Over the Socket.IO websocket it also reports this PC and every printer it can
 * reach (printers installed in Windows/CUPS - USB, serial, network queues - plus
 * TCP/9100 printers on the WiFi/LAN), so Superadmin Settings can choose which
 * printers receive KOTs and which receive Bills.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const net = require('net');
const http = require('http');
const crypto = require('crypto');
const { execFile } = require('child_process');
const io = require('socket.io-client');
const { ThermalPrinter, PrinterTypes, CharacterSet, BreakLine } = require('node-thermal-printer');

// Global crash guards – log the error but do NOT let the process die.
process.on('uncaughtException', (err) => {
  console.error(`[FATAL] Uncaught exception (agent kept alive): ${err.message}`);
  console.error(err.stack || err);
});
process.on('unhandledRejection', (reason) => {
  console.error(`[FATAL] Unhandled promise rejection (agent kept alive):`, reason);
});

const SERVER_URL = (process.env.SERVER_URL || 'https://keabythepool.com').replace(/\/+$/, '');
const PRINT_AGENT_KEY = process.env.PRINT_AGENT_KEY || '';
const AGENT_ID = process.env.PRINT_AGENT_ID || os.hostname();

// Optional always-on counter printer given as a device path/URI, e.g. PRINTER_INTERFACE=/dev/usb/lp0.
// "printer:auto" needs a native driver module that is not installed (it always failed with
// "No driver set!"), so USB printers are now chosen from this PC's printer list in Superadmin Settings.
const COUNTER_INTERFACE = process.env.COUNTER_PRINTER_ENABLED !== 'false'
  && process.env.PRINTER_INTERFACE
  && !/^printer:/i.test(process.env.PRINTER_INTERFACE)
  ? process.env.PRINTER_INTERFACE
  : '';
const DEFAULT_PRINTER_PORT = validPort(process.env.PRINTER_PORT, 9100);
const LAN_PRINTER_COPIES = validCopies(process.env.LAN_PRINTER_COPIES, 1);
const PRINT_RETRIES = Math.max(1, Number.parseInt(process.env.PRINT_RETRIES || '3', 10));

const AUTO_DISCOVER_PRINTERS = process.env.AUTO_DISCOVER_PRINTERS !== 'false';
const DISCOVERY_SUBNETS = String(process.env.DISCOVERY_SUBNETS || '')
  .split(',')
  .map(value => value.trim().replace(/\.$/, ''))
  .filter(Boolean);
// WiFi printers in power-save can take several hundred ms to answer the first connection.
const DISCOVERY_TIMEOUT_MS = Math.max(100, Number.parseInt(process.env.DISCOVERY_TIMEOUT_MS || '800', 10));
const DISCOVERY_CONCURRENCY = Math.max(1, Math.min(64, Number.parseInt(process.env.DISCOVERY_CONCURRENCY || '32', 10)));
const DISCOVERY_INTERVAL_MS = Math.max(60000, Number.parseInt(process.env.DISCOVERY_INTERVAL_MS || '300000', 10));
const PRINT_JOB_POLL_MS = Math.max(3000, Number.parseInt(process.env.PRINT_JOB_POLL_MS || '5000', 10));

const PRINTED_HISTORY_FILE = process.env.PRINTED_HISTORY_FILE || path.join(__dirname, '.printed-kots.json');
const PRINT_HISTORY_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_PRINT_HISTORY = 10000;

// Registries saved before the KOT/Bill checkboxes existed keep the old role behaviour.
const LEGACY_KOT_ROLES = ['kitchen', 'bar', 'all'];
const LEGACY_BILL_ROLES = ['reception', 'counter', 'cashier'];

// Single-instance guard & Local Health Server
const SINGLE_INSTANCE_PORT = 39281;
let localHealthServer;
let socket;

function acquireInstanceLock() {
  localHealthServer = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    if (req.url === '/health' || req.url === '/status' || req.url === '/') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        status: 'running',
        agentId: AGENT_ID,
        hostname: os.hostname(),
        socketConnected: Boolean(socket?.connected),
        uptime: Math.floor(process.uptime()),
        pid: process.pid,
        time: new Date().toISOString()
      }));
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found' }));
  });

  localHealthServer.once('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`====================================================`);
      console.log(`[INFO] Kea Print Agent is ALREADY RUNNING on this PC.`);
      console.log(`[INFO] Port ${SINGLE_INSTANCE_PORT} is active.`);
      console.log(`[INFO] Exiting this duplicate window to prevent conflicts.`);
      console.log(`====================================================`);
      setTimeout(() => process.exit(3), 1000); // watchdog.bat: 3 = already running, stop this watchdog
    } else {
      console.error(`[Lock] Server error: ${err.message}`);
      startCloudSocket();
    }
  });

  localHealthServer.listen(SINGLE_INSTANCE_PORT, '127.0.0.1', () => {
    console.log(`[Lock] Single-instance lock acquired on http://127.0.0.1:${SINGLE_INSTANCE_PORT}`);
    startCloudSocket();
  });
}


const wait = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

function validPort(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 && parsed <= 65535 ? parsed : fallback;
}

function validCopies(value, fallback = 1) {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 && parsed <= 5 ? parsed : fallback;
}

function getEventId(order) {
  if (order.eventId) return String(order.eventId);
  const cleanOrderNumber = String(order.orderNumber || '').replace(/^CD-/, '');
  const orderIdentity = order._id?.toString() || order.id?.toString() || order.orderNumber || 'unknown';
  const ticketIdentity = order.kotTicket || `KOT-${cleanOrderNumber}`;
  return `${orderIdentity}:${ticketIdentity}`;
}

function loadSuccessfulCopies() {
  try {
    const parsed = JSON.parse(fs.readFileSync(PRINTED_HISTORY_FILE, 'utf8'));
    const cutoff = Date.now() - PRINT_HISTORY_TTL_MS;
    return new Map(
      Object.entries(parsed || {})
        .filter(([, printedAt]) => Number(printedAt) >= cutoff)
        .slice(-MAX_PRINT_HISTORY)
    );
  } catch (error) {
    if (error.code !== 'ENOENT') console.warn(`Could not load print history: ${error.message}`);
    return new Map();
  }
}

function saveSuccessfulCopies() {
  const entries = Array.from(successfulCopies.entries()).slice(-MAX_PRINT_HISTORY);
  const temporaryFile = `${PRINTED_HISTORY_FILE}.tmp`;
  fs.writeFileSync(temporaryFile, JSON.stringify(Object.fromEntries(entries), null, 2));
  fs.renameSync(temporaryFile, PRINTED_HISTORY_FILE);
}

async function runWithRetry(label, operation) {
  let lastError;
  for (let attempt = 1; attempt <= PRINT_RETRIES; attempt += 1) {
    try {
      await operation();
      return;
    } catch (error) {
      lastError = error;
      console.error(`${label} failed (${attempt}/${PRINT_RETRIES}): ${error.message}`);
      // Do not retry on permanent errors like invalid printer name
      if (/The printer name is invalid|not found|does not exist/i.test(error.message)) {
        break;
      }
      if (attempt < PRINT_RETRIES) await wait(Math.min(attempt * 500, 1000));
    }
  }
  throw lastError;
}

// ─── Printers installed on this PC (USB cable, serial, Windows/CUPS queues) ───

function runCommand(command, args, env) {
  return new Promise((resolve, reject) => {
    execFile(command, args, {
      windowsHide: true,
      timeout: 60000,
      maxBuffer: 10 * 1024 * 1024,
      env: env ? { ...process.env, ...env } : process.env
    }, (error, stdout, stderr) => {
      if (error) {
        const detail = String(stderr || stdout || '').trim();
        reject(new Error(detail ? `${error.message.split('\n')[0]}: ${detail}` : error.message));
      } else {
        resolve(String(stdout || ''));
      }
    });
  });
}

// -EncodedCommand avoids all quoting problems; printer name and file path travel via env vars.
function runPowerShell(script, env) {
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  return runCommand('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], env);
}

const WINDOWS_LIST_PRINTERS = `
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;
$ErrorActionPreference = 'SilentlyContinue'
$arr = @()
try {
  $arr = @(Get-CimInstance Win32_Printer)
} catch {}
if (-not $arr -or $arr.Count -eq 0) {
  try {
    $arr = @(Get-WmiObject Win32_Printer)
  } catch {}
}
if (-not $arr -or $arr.Count -eq 0) {
  try {
    $arr = @(Get-Printer)
  } catch {}
}
$list = @()
foreach ($p in $arr) {
  if ($p -and $p.Name) {
    $list += [PSCustomObject]@{
      Name = [string]$p.Name
      PortName = [string]$p.PortName
      WorkOffline = [bool]($p.WorkOffline)
    }
  }
}
if ($list.Count -eq 0) {
  Write-Output '[]'
} else {
  @($list) | ConvertTo-Json -Compress
}
`;

// Classic winspool RAW printing (Microsoft KB322091): ESC/POS bytes reach any installed
// USB/serial/network queue untouched, without native Node printer modules.
// The C# helper is compiled ONCE at startup and cached as a DLL for instant prints.

const WINSPOOL_CS = `
using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
public static class KeaRawPrint {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public class DocInfo { public string DocName; public string OutputFile; public string DataType; }
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)]
  static extern bool OpenPrinter(string name, out IntPtr handle, IntPtr defaults);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool ClosePrinter(IntPtr handle);
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)]
  static extern int StartDocPrinter(IntPtr handle, int level, [In] DocInfo info);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool EndDocPrinter(IntPtr handle);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool StartPagePrinter(IntPtr handle);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool EndPagePrinter(IntPtr handle);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool WritePrinter(IntPtr handle, byte[] data, int length, out int written);
  public static void Send(string printer, byte[] data) {
    IntPtr handle;
    if (!OpenPrinter(printer, out handle, IntPtr.Zero)) throw new Win32Exception(Marshal.GetLastWin32Error());
    try {
      DocInfo info = new DocInfo();
      info.DocName = "Kea Print";
      info.DataType = "RAW";
      if (StartDocPrinter(handle, 1, info) == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
      try {
        if (!StartPagePrinter(handle)) throw new Win32Exception(Marshal.GetLastWin32Error());
        int written;
        bool ok = WritePrinter(handle, data, data.Length, out written);
        EndPagePrinter(handle);
        if (!ok || written != data.Length) throw new Win32Exception(Marshal.GetLastWin32Error());
      } finally {
        EndDocPrinter(handle);
      }
    } finally {
      ClosePrinter(handle);
    }
  }
  public static int Main(string[] args) {
    if (args.Length < 2) { Console.Error.WriteLine("Usage: KeaRawPrint <printerName> <filePath>"); return 1; }
    Send(args[0], File.ReadAllBytes(args[1]));
    return 0;
  }
}
`;

let cachedPrintExe = '';

async function compilePrintHelper() {
  if (process.platform !== 'win32') return;
  const cacheDir = path.join(__dirname, '.cache');
  const csFile = path.join(cacheDir, 'KeaRawPrint.cs');
  const exeFile = path.join(cacheDir, 'KeaRawPrint.exe');
  try {
    fs.mkdirSync(cacheDir, { recursive: true });
    // Only recompile if source changed or exe missing
    const csExists = fs.existsSync(csFile);
    const exeExists = fs.existsSync(exeFile);
    const sourceMatch = csExists && fs.readFileSync(csFile, 'utf8') === WINSPOOL_CS;
    if (sourceMatch && exeExists) {
      cachedPrintExe = exeFile;
      console.log('Print helper: using cached KeaRawPrint.exe (instant prints)');
      return;
    }
    fs.writeFileSync(csFile, WINSPOOL_CS);
    // Use .NET Framework csc.exe (always present on Windows)
    const cscPaths = [
      path.join(process.env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe'),
      path.join(process.env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework', 'v4.0.30319', 'csc.exe')
    ];
    let cscPath = '';
    for (const p of cscPaths) {
      if (fs.existsSync(p)) { cscPath = p; break; }
    }
    if (!cscPath) {
      console.warn('Print helper: csc.exe not found, falling back to PowerShell per-print compile');
      return;
    }
    console.log('Compiling print helper (one-time)...');
    await runCommand(cscPath, ['/nologo', '/optimize', '/out:' + exeFile, csFile]);
    cachedPrintExe = exeFile;
    console.log('Print helper: compiled KeaRawPrint.exe — prints will be instant!');
  } catch (err) {
    console.warn(`Print helper compile failed (will use PowerShell fallback): ${err.message}`);
  }
}

// Fallback: PowerShell inline compile (slow, ~1-2s per print)
const WINDOWS_RAW_PRINT_PS = `
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class KeaRawPrint {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public class DocInfo { public string DocName; public string OutputFile; public string DataType; }
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)]
  static extern bool OpenPrinter(string name, out IntPtr handle, IntPtr defaults);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool ClosePrinter(IntPtr handle);
  [DllImport("winspool.drv", CharSet = CharSet.Unicode, SetLastError = true)]
  static extern int StartDocPrinter(IntPtr handle, int level, [In] DocInfo info);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool EndDocPrinter(IntPtr handle);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool StartPagePrinter(IntPtr handle);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool EndPagePrinter(IntPtr handle);
  [DllImport("winspool.drv", SetLastError = true)]
  static extern bool WritePrinter(IntPtr handle, byte[] data, int length, out int written);
  public static void Send(string printer, byte[] data) {
    IntPtr handle;
    if (!OpenPrinter(printer, out handle, IntPtr.Zero)) throw new Win32Exception(Marshal.GetLastWin32Error());
    try {
      DocInfo info = new DocInfo();
      info.DocName = "Kea Print";
      info.DataType = "RAW";
      if (StartDocPrinter(handle, 1, info) == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
      try {
        if (!StartPagePrinter(handle)) throw new Win32Exception(Marshal.GetLastWin32Error());
        int written;
        bool ok = WritePrinter(handle, data, data.Length, out written);
        EndPagePrinter(handle);
        if (!ok || written != data.Length) throw new Win32Exception(Marshal.GetLastWin32Error());
      } finally {
        EndDocPrinter(handle);
      }
    } finally {
      ClosePrinter(handle);
    }
  }
}
'@
[KeaRawPrint]::Send($env:KEA_PRINTER_NAME, [System.IO.File]::ReadAllBytes($env:KEA_PRINT_FILE))
`;

function classifyPrinterPort(port, printerName = '') {
  const value = String(port || '').trim();
  const name = String(printerName || '').trim();
  // Virtual queues (Print to PDF/XPS, OneNote, Fax, CUPS-PDF) cannot print receipts.
  if (/^(PORTPROMPT:|FILE:|NUL:?|SHRFAX:)$/i.test(value) || /^(cups-pdf|file):/i.test(value)) return null;
  if (/pdf|xps|onenote|fax|anydesk|teamviewer|send to|microsoft print/i.test(name)) return null;

  if (/usb/i.test(value) || /usb/i.test(name)) return { connection: 'usb' };
  if (/^(LPT|COM)\d+:?$/i.test(value) || /^(parallel|serial):/i.test(value)) return { connection: 'wired' };
  const ip = value.match(/(?:^|\D)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)/);
  if (ip) return { connection: 'network', host: ip[1] };
  if (/^(WSD|ipps?|lpd|socket|dnssd|https?|smb)\b/i.test(value) || value.startsWith('\\\\')) return { connection: 'network' };

  // If the printer name matches receipt/thermal/kitchen printer hardware, treat as USB
  if (/pos|thermal|receipt|kitchen|kitchan|bill|retsol|epson|tvs|tvs-e|xprinter|tsc|bixolon|star|citizen/i.test(name)) {
    return { connection: 'usb' };
  }
  return { connection: 'other' };
}

async function listSystemPrinters() {
  try {
    let rows = [];
    if (process.platform === 'win32') {
      let output = '';
      try {
        output = (await runPowerShell(WINDOWS_LIST_PRINTERS)).trim();
        if (output) {
          const parsed = JSON.parse(output);
          let rawItems = [];
          if (Array.isArray(parsed)) {
            rawItems = parsed;
          } else if (parsed && Array.isArray(parsed.value)) {
            // PowerShell 5.1 ConvertTo-Json -InputObject array wrapper
            rawItems = parsed.value;
          } else if (parsed && typeof parsed === 'object' && (parsed.Name || parsed.systemName)) {
            rawItems = [parsed];
          }
          rows = rawItems
            .filter(row => row && (row.Name || row.systemName))
            .map(row => ({
              systemName: String(row.Name || row.systemName || '').trim(),
              port: String(row.PortName || row.port || '').trim(),
              offline: row.WorkOffline === true || row.offline === true
            }));
        }
      } catch (psErr) {
        console.warn(`[PrinterEnum] PowerShell discovery failed: ${psErr.message}`);
      }

      // If PowerShell returned 0 printers, try WMIC and Registry fallbacks
      if (rows.length === 0) {
        // Fallback 1: WMIC
        try {
          const wmicOut = await runCommand('wmic', ['printer', 'get', 'Name,PortName,WorkOffline', '/format:csv']);
          const lines = wmicOut.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
          for (let i = 1; i < lines.length; i++) {
            const parts = lines[i].split(',');
            if (parts.length >= 3) {
              const name = parts[1] ? parts[1].trim() : '';
              const port = parts[2] ? parts[2].trim() : '';
              const offline = parts[3] ? parts[3].trim().toUpperCase() === 'TRUE' : false;
              if (name) rows.push({ systemName: name, port, offline });
            }
          }
        } catch (wmicErr) {
          // Fallback 2: Windows Registry (HKCU)
          try {
            const regOut = await runCommand('reg', ['query', 'HKCU\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Devices']);
            const regLines = regOut.split(/\r?\n/).filter(Boolean);
            for (const line of regLines) {
              const match = line.match(/^\s+(.+?)\s+REG_SZ\s+(?:.*?,)?(.*)$/i);
              if (match) {
                rows.push({ systemName: match[1].trim(), port: match[2].trim(), offline: false });
              }
            }
          } catch (regErr) {
            console.warn(`[PrinterEnum] Windows registry HKCU fallback failed: ${regErr.message}`);
          }

          // Fallback 3: Windows Registry (HKLM)
          if (rows.length === 0) {
            try {
              const hklmOut = await runCommand('reg', ['query', 'HKLM\\SYSTEM\\CurrentControlSet\\Control\\Print\\Printers']);
              const hklmLines = hklmOut.split(/\r?\n/).filter(Boolean);
              for (const line of hklmLines) {
                const match = line.match(/Print\\Printers\\(.+)$/i);
                if (match && match[1]) {
                  rows.push({ systemName: match[1].trim(), port: '', offline: false });
                }
              }
            } catch (hklmErr) {
              console.warn(`[PrinterEnum] Windows registry HKLM fallback failed: ${hklmErr.message}`);
            }
          }
        }
      }
    } else {
      const output = await runCommand('lpstat', ['-v'], { LC_ALL: 'C', LANG: 'C' });
      rows = output.split('\n')
        .map(line => line.match(/^device for (.+?):\s+(\S+)/))
        .filter(Boolean)
        .map(match => ({ systemName: match[1], port: match[2], offline: false }));
    }

    console.log(`[PrinterEnum] Raw system printers detected on PC (${rows.length}):`, rows.map(r => `"${r.systemName}" (port: ${r.port || 'none'})`).join(', ') || 'none');

    return rows.flatMap(row => {
      // PDF/XPS/OneNote/Fax and remote-support queues are never receipt printers.
      const isVirtual = /pdf|xps|onenote|fax|anydesk|teamviewer|send to|microsoft print/i.test(row.systemName || '');
      const kind = row.systemName && !isVirtual ? classifyPrinterPort(row.port, row.systemName) : null;
      if (!kind) return [];
      return [{
        type: 'system',
        systemName: row.systemName,
        name: row.systemName,
        connection: kind.connection,
        host: kind.host || '',
        status: row.offline ? 'offline' : ''
      }];
    });
  } catch (error) {
    console.warn(`Could not list installed printers: ${error.message}`);
    return [];
  }
}

async function printRawToSystemPrinter(systemName, buffer) {
  const file = path.join(os.tmpdir(), `kea-print-${crypto.randomUUID()}.bin`);
  fs.writeFileSync(file, buffer);
  try {
    if (process.platform === 'win32') {
      if (cachedPrintExe) {
        // Fast path: pre-compiled EXE (~0.1s)
        await runCommand(cachedPrintExe, [systemName, file]);
      } else {
        // Slow fallback: PowerShell recompiles C# every time (~1-2s)
        await runPowerShell(WINDOWS_RAW_PRINT_PS, { KEA_PRINTER_NAME: systemName, KEA_PRINT_FILE: file });
      }
    } else {
      await runCommand('lp', ['-d', systemName, '-o', 'raw', file]);
    }
  } finally {
    fs.rm(file, { force: true }, () => {});
  }
}

// node-thermal-printer accepts a custom interface object with execute(buffer).
function printerInterfaceFor(target) {
  if (target.type === 'system') {
    return { execute: buffer => printRawToSystemPrinter(target.systemName, buffer), isPrinterConnected: async () => true };
  }
  if (target.type === 'device') return target.interface;
  return `tcp://${target.host}:${target.port}`;
}

// ─── LAN/WiFi discovery (TCP/9100) ───

// VPN/virtual adapters would otherwise crowd the real restaurant LAN out of the scan list.
const VIRTUAL_ADAPTER = /virtual|vmware|vbox|hyper-v|vethernet|docker|wsl|loopback|tailscale|zerotier|hamachi|^br-|^veth|^utun|^awdl|^llw/i;

function inferSubnetPrefixes() {
  const prefixes = new Set(DISCOVERY_SUBNETS);
  for (const [adapterName, entries] of Object.entries(os.networkInterfaces())) {
    if (VIRTUAL_ADAPTER.test(adapterName)) continue;
    for (const entry of entries || []) {
      const family = typeof entry.family === 'string' ? entry.family : (entry.family === 4 ? 'IPv4' : 'IPv6');
      if (entry.internal || family !== 'IPv4' || String(entry.address).startsWith('169.254.')) continue;
      const octets = String(entry.address || '').split('.');
      // ponytail: scans each adapter's /24 only; list extra ranges in DISCOVERY_SUBNETS for a wider LAN.
      if (octets.length === 4) prefixes.add(octets.slice(0, 3).join('.'));
    }
  }
  return Array.from(prefixes).slice(0, 4);
}

function probePrinter(host, port) {
  return new Promise(resolve => {
    const client = new net.Socket();
    let settled = false;
    const finish = found => {
      if (settled) return;
      settled = true;
      client.destroy();
      resolve(found);
    };
    client.setTimeout(DISCOVERY_TIMEOUT_MS);
    client.once('connect', () => finish(true));
    client.once('timeout', () => finish(false));
    client.once('error', () => finish(false));
    client.connect(port, host);
  });
}

async function scanSubnet(prefix, port) {
  const found = [];
  let nextHost = 1;
  const worker = async () => {
    while (nextHost <= 254) {
      const hostNumber = nextHost;
      nextHost += 1;
      const host = `${prefix}.${hostNumber}`;
      if (await probePrinter(host, port)) found.push(host);
    }
  };
  await Promise.all(Array.from({ length: DISCOVERY_CONCURRENCY }, () => worker()));
  return found;
}

let discoveredPrinters = [];
let systemPrinters = [];
let discoveryRunning = null;
let lastLanScanAt = 0;
async function refreshDiscoveredPrinters() {
  if (discoveryRunning) return discoveryRunning;

  discoveryRunning = (async () => {
    const installedPrinters = await listSystemPrinters();

    if (AUTO_DISCOVER_PRINTERS) {
      const prefixes = inferSubnetPrefixes();
      if (prefixes.length === 0) {
        console.warn('LAN discovery skipped: no IPv4 subnet found.');
      } else {
        console.log(`Scanning ${prefixes.join(', ')} for TCP/${DEFAULT_PRINTER_PORT} printers...`);
        const scanResults = await Promise.all(prefixes.map(prefix => scanSubnet(prefix, DEFAULT_PRINTER_PORT)));
        const hosts = Array.from(new Set(scanResults.flat())).sort();
        discoveredPrinters = hosts.map(host => ({
          id: `discovered-${host.replace(/\./g, '-')}-${DEFAULT_PRINTER_PORT}`,
          name: `Auto-discovered ${host}`,
          role: 'all',
          host,
          port: DEFAULT_PRINTER_PORT,
          copies: LAN_PRINTER_COPIES,
          enabled: true,
          discovered: true
        }));
        console.log(`LAN discovery found ${discoveredPrinters.length} printer(s): ${hosts.join(', ') || 'none'}`);
        lastLanScanAt = Date.now();
      }
    }

    // Keep all real system printers installed on this PC.
    // If an installed printer has an IP that was also auto-discovered over LAN, keep the named
    // system printer and remove the duplicate generic 'Network printer x.x.x.x' from discoveredPrinters.
    const systemHosts = new Set(installedPrinters.map(p => p.host).filter(Boolean));
    if (systemHosts.size > 0) {
      discoveredPrinters = discoveredPrinters.filter(p => !systemHosts.has(p.host));
    }
    systemPrinters = installedPrinters;
    console.log(`Installed printers on this PC (${systemPrinters.length}): ${systemPrinters.map(printer => `${printer.systemName} [${printer.connection}]`).join(', ') || 'none'}`);

    registerWithBackend();
    return discoveredPrinters;
  })().finally(() => { discoveryRunning = null; });

  return discoveryRunning;
}

// At boot the PC may start before WiFi/spooler are ready, and a WiFi printer that stops answering
// usually got a new DHCP IP: rescan (at most once a minute) so new printers are auto-added and ticked.
function rescanSoon() {
  if (Date.now() - lastLanScanAt < 60000) return;
  refreshDiscoveredPrinters().catch(error => console.error(`Printer rescan failed: ${error.message}`));
}

// Tells the backend (websocket) which printers this PC can reach, for Superadmin Settings.
function registerWithBackend() {
  if (!socket.connected) return;
  socket.emit('print-agent:register', {
    key: PRINT_AGENT_KEY,
    agentId: AGENT_ID,
    name: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    printers: [
      ...systemPrinters,
      ...discoveredPrinters.map(printer => ({
        type: 'tcp',
        name: `Network printer ${printer.host}`,
        host: printer.host,
        port: printer.port,
        connection: 'network'
      }))
    ]
  });
}

function parseEnvironmentPrinters() {
  const values = [
    { name: 'Kitchen Printer', role: 'kitchen', host: process.env.KITCHEN_PRINTER_IP },
    { name: 'Bar Printer', role: 'bar', host: process.env.BAR_PRINTER_IP },
    { name: 'Reception Printer', role: 'reception', host: process.env.RECEPTION_PRINTER_IP },
    ...String(process.env.WIFI_PRINTER_IPS || '').split(',').filter(Boolean).map((host, index) => ({
      name: `Environment WiFi Printer ${index + 1}`,
      role: 'all',
      host
    }))
  ];

  return values
    .map((printer, index) => {
      const raw = String(printer.host || '').trim().replace(/^tcp:\/\//i, '');
      if (!raw) return null;
      const match = raw.match(/^(.+?)(?::(\d+))?$/);
      const host = match?.[1];
      const port = validPort(match?.[2], DEFAULT_PRINTER_PORT);
      return {
        id: `env-${printer.role}-${index}-${host.replace(/[^a-z0-9]/gi, '-')}-${port}`,
        name: printer.name,
        role: printer.role,
        host,
        port,
        copies: LAN_PRINTER_COPIES,
        enabled: true
      };
    })
    .filter(Boolean);
}

let livePrinterConfig = null;

function toTarget(printer, defaultPort = DEFAULT_PRINTER_PORT) {
  if (!printer || printer.enabled === false) return null;
  const role = String(printer.role || 'all').toLowerCase();
  const base = {
    id: printer.id,
    name: printer.name || printer.systemName || `${role} printer`,
    copies: validCopies(printer.copies, LAN_PRINTER_COPIES),
    kot: typeof printer.kot === 'boolean' ? printer.kot : LEGACY_KOT_ROLES.includes(role),
    bill: typeof printer.bill === 'boolean' ? printer.bill : LEGACY_BILL_ROLES.includes(role)
  };

  if (printer.type === 'system') {
    // An installed/USB printer belongs to exactly one PC; other agents must not touch it.
    if (printer.agentId !== AGENT_ID || !printer.systemName) return null;
    return { ...base, type: 'system', systemName: printer.systemName, endpointKey: `system:${printer.systemName}` };
  }

  const host = String(printer.host || printer.ip || '').trim();
  if (!host) return null;
  const port = validPort(printer.port, defaultPort);
  // ponytail: with several PCs online every agent prints LAN printers; pin them to one agent if that ever happens.
  return { ...base, type: 'tcp', host, port, endpointKey: `tcp:${host}:${port}` };
}

function buildTargets(job) {
  const config = livePrinterConfig?.version ? livePrinterConfig : job.printerConfig;
  const jobFlag = job.jobType === 'bill' ? 'bill' : 'kot';
  const targets = [];
  const endpointKeys = new Set();

  const addTarget = target => {
    if (!target || !target[jobFlag] || endpointKeys.has(target.endpointKey)) return;
    endpointKeys.add(target.endpointKey);
    targets.push(target);
  };

  if (COUNTER_INTERFACE) {
    addTarget({
      id: 'counter-device',
      name: 'Counter Printer',
      type: 'device',
      interface: COUNTER_INTERFACE,
      copies: 1,
      kot: true,
      bill: true,
      endpointKey: `device:${COUNTER_INTERFACE}`
    });
  }

  const registry = config?.printers || [];
  for (const printer of registry) addTarget(toTarget(printer, config?.defaultPort || DEFAULT_PRINTER_PORT));

  // Detected printers reach the registry through the backend (auto-ticked for KOT + Bill by default).
  for (const printer of parseEnvironmentPrinters()) addTarget(toTarget(printer));

  return targets;
}

const successfulCopies = loadSuccessfulCopies();
const queuedEvents = new Set();

const endpointQueues = new Map();
// One physical job at a time per printer. A failure must reach the caller so it is reported
// and retried, but it must not break the queue for the next ticket on that printer.
function runOnEndpointQueue(endpointKey, fn) {
  const previous = endpointQueues.get(endpointKey) || Promise.resolve();
  const result = previous.then(fn);
  endpointQueues.set(endpointKey, result.catch(() => {}).then(() => wait(300)));
  return result;
}

async function printTarget(job, eventId, target) {
  const results = [];
  for (let copy = 1; copy <= target.copies; copy += 1) {
    const successKey = `${eventId}::${target.endpointKey}::copy-${copy}`;
    if (successfulCopies.has(successKey)) {
      results.push({ target: target.name, endpoint: target.endpointKey, copy, status: 'already-printed' });
      continue;
    }

    const printerInterface = printerInterfaceFor(target);
    const label = `${target.name} ${copy}/${target.copies}`;

    try {
      await runOnEndpointQueue(target.endpointKey, () =>
        runWithRetry(label, () =>
          job.jobType === 'bill'
            ? printBillToInterface(job, printerInterface, label)
            : printKOTToInterface(job, printerInterface, label)
        )
      );
      successfulCopies.set(successKey, Date.now());
      saveSuccessfulCopies();
      console.log(`Printed ${job.jobType === 'bill' ? 'Bill' : 'KOT'} ${job.billNumber || job.kotTicket || job.orderNumber} on ${label}`);
      results.push({ target: target.name, endpoint: target.endpointKey, copy, status: 'printed' });
    } catch (error) {
      results.push({ target: target.name, endpoint: target.endpointKey, copy, status: 'failed', error: error.message });
      if (target.type === 'tcp') rescanSoon();
    }
  }
  return results;
}

// The backend keeps every job in its outbox until an agent confirms it. Emits made while the
// socket is reconnecting are buffered by socket.io and sent on reconnect.
function reportJob(eventId, succeeded, results, errorMessage = '') {
  socket.emit('print-agent:job-result', { eventId, ok: succeeded, results, error: errorMessage });
}

async function processJob(job) {
  const eventId = getEventId(job);
  const ticketLabel = job.billNumber || job.kotTicket || job.orderNumber || eventId;
  const jobName = job.jobType === 'bill' ? 'Bill' : 'KOT';
  const config = livePrinterConfig?.version ? livePrinterConfig : job.printerConfig;

  if (config?.enabled === false) {
    const results = [{ target: 'all', status: 'skipped', reason: 'Central auto-print is disabled' }];
    await reportJob(eventId, true, results);
    console.log(`Skipped disabled print job ${ticketLabel}`);
    return;
  }

  const targets = buildTargets(job);
  if (targets.length === 0) {
    // Another PC may own the selected printer, so never report a failure for it from here.
    console.warn(`No printer on this PC is selected for ${jobName} ${ticketLabel}. Select printers in Superadmin Settings.`);
    return;
  }

  const nestedResults = await Promise.all(targets.map(target => printTarget(job, eventId, target)));
  const results = nestedResults.flat();
  const failed = results.filter(result => result.status === 'failed');

  if (failed.length > 0) {
    const message = `${failed.length} printer copy/copies failed (${failed.map(result => `${result.target}: ${result.error}`).join('; ')}); successful targets were saved and will not duplicate`;
    await reportJob(eventId, false, results, message);
    throw new Error(message);
  }

  await reportJob(eventId, true, results);
  console.log(`Completed ${jobName} ${ticketLabel} on ${targets.length} physical printer(s)`);
}

const processedEventIds = new Map();
const EVENT_DEDUPE_TTL_MS = 10 * 60 * 1000;

function enqueueJob(job, source = 'socket') {
  const eventId = getEventId(job);
  const now = Date.now();

  // Prune expired entries older than 10 minutes
  for (const [id, time] of processedEventIds.entries()) {
    if (now - time > EVENT_DEDUPE_TTL_MS) processedEventIds.delete(id);
  }

  if (processedEventIds.has(eventId)) {
    // The outbox is polled every few seconds; only duplicate live events are worth logging.
    if (source !== 'backend-outbox') console.log(`[Dedupe] Print job ${eventId} already handled within last 10m; ignoring duplicate from ${source}`);
    return;
  }
  processedEventIds.set(eventId, now);

  if (queuedEvents.has(eventId)) return;
  queuedEvents.add(eventId);
  console.log(`Queued ${job.jobType === 'bill' ? 'Bill' : 'KOT'} ${job.billNumber || job.kotTicket || job.orderNumber || eventId} from ${source}`);

  // Jobs run independently; per-printer queues keep ticket order, so one offline printer
  // can no longer hold back tickets for every other printer.
  processJob(job)
    .catch(error => {
      processedEventIds.delete(eventId); // Allow retry if processJob failed completely
      console.error(`Print Job ${eventId} remains pending: ${error.message}`);
    })
    .finally(() => queuedEvents.delete(eventId));
}

async function handleTestPrint(printer) {
  const target = toTarget({ ...printer, kot: true, bill: true }, livePrinterConfig?.defaultPort || DEFAULT_PRINTER_PORT);
  if (!target) return;
  try {
    await runOnEndpointQueue(target.endpointKey, async () => {
      const slip = new ThermalPrinter({
        type: PrinterTypes.EPSON,
        interface: printerInterfaceFor(target),
        characterSet: CharacterSet.SLOVENIA,
        width: 42
      });
      slip.alignCenter();
      slip.bold(true);
      slip.println('KEA BY THE POOL');
      slip.bold(false);
      slip.println('PRINTER TEST OK');
      slip.println(target.name);
      slip.println(`PC: ${os.hostname()}`);
      slip.println(new Date().toLocaleString('en-IN'));
      slip.newLine();
      slip.newLine();
      slip.cut();
      await slip.execute();
    });
    console.log(`Test print sent to ${target.name}`);
    socket.emit('print-agent:test-result', { printerName: target.name, ok: true });
  } catch (error) {
    console.error(`Test print failed on ${target.name}: ${error.message}`);
    socket.emit('print-agent:test-result', { printerName: target.name, ok: false, error: error.message });
  }
}

// Catch-up for KOTs/Bills emitted while this agent was offline or reconnecting, and retries of
// jobs where a printer failed. Printed copies are remembered, so nothing prints twice.
let polling = false;
async function pollPendingJobs() {
  if (polling || !socket?.connected) return;
  polling = true;
  try {
    const response = await socket.timeout(10000).emitWithAck('print-agent:pending', {});
    for (const job of response?.jobs || []) {
      if (job?.payload) enqueueJob({ ...job.payload, eventId: job.eventId, jobType: job.jobType || job.payload.jobType || 'kot' }, 'backend-outbox');
    }
  } catch (_) {
    // Reconnecting, or a backend without the outbox handler: live socket events still print.
  } finally {
    polling = false;
  }
}

function startCloudSocket() {
  console.log('====================================================');
  console.log('  Kea By The Pool - Reliable Multi-Printer Print Agent');
  console.log('====================================================');
  console.log(`Server: ${SERVER_URL}`);
  console.log(`Agent ID: ${AGENT_ID}`);
  console.log(`Counter printer: ${COUNTER_INTERFACE || 'not set (select printers in Superadmin Settings)'}`);
  console.log(`LAN auto-discovery: ${AUTO_DISCOVER_PRINTERS ? 'enabled' : 'disabled'}`);
  console.log(`Remembered successful copies: ${successfulCopies.size}`);

  socket = io(SERVER_URL, {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 4000,
    reconnectionAttempts: Infinity,
    timeout: 8000
  });

  // Rapid Heartbeat: Ping backend every 2 seconds to guarantee 100% online status
  const HEARTBEAT_INTERVAL_MS = 2000;
  let missedHeartbeats = 0;
  let lastHeartbeatAck = Date.now();

  function sendHeartbeat() {
    try {
      if (!socket.connected) {
        missedHeartbeats++;
        if (missedHeartbeats >= 2) {
          console.warn(`[Watchdog] Socket disconnected for ${missedHeartbeats * 2}s. Forcing immediate reconnect...`);
          socket.connect();
        }
        return;
      }

      // Detect silent zombie socket (e.g. WiFi reconnect or PC sleep/wake)
      if (Date.now() - lastHeartbeatAck > 12000) {
        console.warn(`[Watchdog] No heartbeat ack received for ${Math.round((Date.now() - lastHeartbeatAck) / 1000)}s. Resetting socket...`);
        lastHeartbeatAck = Date.now();
        socket.disconnect().connect();
        return;
      }

      missedHeartbeats = 0;
      socket.emit('print-agent:heartbeat', {
        agentId: AGENT_ID,
        name: os.hostname(),
        time: Date.now()
      });
    } catch (err) {
      console.error(`[Watchdog] Heartbeat error: ${err.message}`);
    }
  }

  socket.on('connect', () => {
    console.log('Connected to backend. Waiting for KOT and Bill print events.');
    lastHeartbeatAck = Date.now();
    registerWithBackend();
    sendHeartbeat();
    pollPendingJobs();
    rescanSoon();
  });

  socket.on('disconnect', reason => {
    console.warn(`Disconnected (${reason}). Reconnecting immediately.`);
    setTimeout(() => {
      if (!socket.connected) socket.connect();
    }, 1000);
  });

  socket.on('connect_error', error => {
    console.error(`Backend connection failed: ${error.message}`);
    setTimeout(() => {
      if (!socket.connected) socket.connect();
    }, 2000);
  });

  socket.on('print-agent:heartbeat-ack', () => {
    lastHeartbeatAck = Date.now();
  });

  socket.on('new-order', order => enqueueJob({ ...order, jobType: 'kot' }, 'socket'));
  socket.on('new-print-job', job => enqueueJob({ ...job, jobType: job.jobType || 'kot' }, 'socket'));
  socket.on('new-bill-print', billJob => enqueueJob({ ...billJob, jobType: 'bill' }, 'socket'));
  socket.on('printer-settings-updated', config => {
    if (config?.version) {
      livePrinterConfig = config;
      console.log(`Printer registry refreshed: ${(config.printers || []).length} configured target(s)`);
    }
  });
  socket.on('printer-scan-request', () => {
    console.log('Printer scan requested from Settings.');
    refreshDiscoveredPrinters().catch(error => console.error(`Printer scan failed: ${error.message}`));
  });
  socket.on('printer-test', printer => { handleTestPrint(printer); });

  compilePrintHelper().catch(err => console.warn(`Print helper init: ${err.message}`));
  refreshDiscoveredPrinters().catch(error => console.error(`Initial LAN discovery failed: ${error.message}`));
  setInterval(() => refreshDiscoveredPrinters().catch(error => console.error(`LAN discovery failed: ${error.message}`)), DISCOVERY_INTERVAL_MS).unref();
  setInterval(pollPendingJobs, PRINT_JOB_POLL_MS).unref();
  setInterval(sendHeartbeat, HEARTBEAT_INTERVAL_MS).unref();
}

acquireInstanceLock();


async function printBillToInterface(bill, printerInterface, printerLabel) {
  const printer = new ThermalPrinter({
    type: PrinterTypes.EPSON,
    interface: printerInterface,
    characterSet: CharacterSet.SLOVENIA,
    breakLine: BreakLine.WORD,
    width: 42
  });

  const billNumber = bill.billNumber || `BILL-${bill.billId || '001'}`;
  const orderNumber = bill.orderNumber || (bill.orderNumbers && bill.orderNumbers.length > 0 ? bill.orderNumbers.join(', ') : '');
  const tableName = bill.tableName || bill.tableNumber || 'Takeaway';
  const customerName = bill.customer?.name || 'Walk-in';
  const billerName = bill.billerName || 'Cashier';
  const timestamp = new Date(bill.createdAt || Date.now());
  const date = timestamp.toLocaleDateString('en-IN');
  const time = timestamp.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });

  printer.alignCenter();
  printer.bold(true);
  printer.setTextSize(1, 1);
  printer.println('KEA BY THE POOL');
  printer.bold(false);
  printer.setTextSize(0, 0);
  printer.println('Dhanora, Risali, Bhilai');
  printer.println('OFFICIAL RECEIPT');
  printer.bold(true);
  printer.println(billNumber);
  printer.bold(false);
  printer.drawLine();

  printer.alignLeft();
  if (orderNumber) printer.println(`ORDER#: #${orderNumber}`);
  printer.println(`TABLE : ${tableName}`);
  printer.println(`GUEST : ${customerName}`);
  printer.println(`STAFF : ${billerName}`);
  printer.println(`TIME  : ${date} ${time}`);
  printer.drawLine();

  printer.bold(true);
  printer.tableCustom([
    { text: 'ITEM', align: 'LEFT', width: 0.50 },
    { text: 'QTY x PRICE', align: 'CENTER', width: 0.25 },
    { text: 'AMT', align: 'RIGHT', width: 0.25 }
  ]);
  printer.bold(false);
  printer.drawLine();

  for (const item of bill.items || []) {
    const itemName = (item.menuItem?.name || item.name || 'Item').substring(0, 20);
    const qtyPrice = `${item.quantity} x ${item.price}`;
    const amount = (item.quantity * item.price).toFixed(2);
    printer.tableCustom([
      { text: itemName, align: 'LEFT', width: 0.50 },
      { text: qtyPrice, align: 'CENTER', width: 0.25 },
      { text: amount, align: 'RIGHT', width: 0.25 }
    ]);
  }

  printer.drawLine();
  printer.println(`Subtotal:                    Rs.${Number(bill.subtotal || 0).toFixed(2)}`);
  if (bill.discount > 0) {
    const discountLabel = bill.discountName ? `Discount (${bill.discountName})` : 'Discount';
    printer.println(`${discountLabel.padEnd(28)} -Rs.${Number(bill.discount).toFixed(2)}`);
  }
  if (Array.isArray(bill.taxDetails) && bill.taxDetails.length > 0) {
    for (const taxItem of bill.taxDetails) {
      printer.println(`${taxItem.name.padEnd(28)}  Rs.${Number(taxItem.amount || 0).toFixed(2)}`);
    }
  } else if (bill.tax > 0) {
    printer.println(`Taxes:                       Rs.${Number(bill.tax).toFixed(2)}`);
  }

  printer.drawLine();
  printer.bold(true);
  printer.println(`TOTAL AMOUNT:                Rs.${Number(bill.total || 0).toFixed(2)}`);
  printer.bold(false);
  if (bill.paymentMethod) {
    printer.println(`Payment Mode: ${String(bill.paymentMethod).toUpperCase()}`);
  }

  printer.drawLine();
  printer.alignCenter();
  printer.bold(true);
  printer.println('THANK YOU FOR VISITING!');
  printer.bold(false);
  printer.println('Please Come Again');
  printer.println(`*** ${printerLabel} ***`);
  printer.newLine();
  printer.newLine();
  printer.cut();

  await printer.execute();
}

async function printKOTToInterface(order, printerInterface, printerLabel) {
  const printer = new ThermalPrinter({
    type: PrinterTypes.EPSON,
    interface: printerInterface,
    characterSet: CharacterSet.SLOVENIA,
    breakLine: BreakLine.WORD,
    width: 42
  });

  const cleanOrderNumber = String(order.orderNumber || '').replace(/^CD-/, '');
  const kotNumber = order.kotTicket || `KOT-${cleanOrderNumber}`;
  const tableName = order.tableName
    || (order.tables?.length > 0
      ? order.tables.map(table => table.name || `Table ${table.tableNumber}`).join(', ')
      : null)
    || order.table?.name
    || (order.table?.tableNumber ? `Table ${order.table.tableNumber}` : null)
    || (order.tableNumber ? `Table ${order.tableNumber}` : 'Takeaway');
  const staffName = order.placedBy?.name || order.user?.name || 'Staff';
  const timestamp = new Date(order.kotCreatedAt || order.createdAt || Date.now());
  const date = timestamp.toLocaleDateString('en-IN');
  const time = timestamp.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });

  printer.alignCenter();
  printer.bold(true);
  printer.setTextSize(1, 1);
  printer.println('KEA BY THE POOL');
  printer.bold(false);
  printer.setTextSize(0, 0);
  printer.println(`${order.kotEventType || 'KOT'} - KITCHEN ORDER TICKET`);
  printer.bold(true);
  printer.println(kotNumber);
  printer.bold(false);
  printer.drawLine();

  printer.alignLeft();
  printer.println(`TABLE : ${tableName}`);
  printer.println(`ORDER#: #${order.orderNumber}`);
  printer.println(`STAFF : ${staffName}`);
  printer.println(`TIME  : ${date} ${time}`);
  printer.drawLine();

  printer.bold(true);
  printer.tableCustom([
    { text: 'ITEM NAME', align: 'LEFT', width: 0.75 },
    { text: 'QTY', align: 'RIGHT', width: 0.25 }
  ]);
  printer.bold(false);
  printer.drawLine();

  for (const item of order.items || []) {
    const itemName = item.menuItem?.name || item.name || 'Item';
    printer.tableCustom([
      { text: itemName, align: 'LEFT', width: 0.75 },
      { text: `x${item.quantity}`, align: 'RIGHT', width: 0.25 }
    ]);
    const itemNote = item.notes || item.instruction || item.specialInstructions || item.note;
    if (itemNote) printer.println(`  > Note: ${itemNote}`);
  }

  const instructions = order.specialInstructions || order.instructions || order.notes;
  if (instructions) {
    printer.drawLine();
    printer.bold(true);
    printer.println('NOTE:');
    printer.bold(false);
    printer.println(instructions);
  }

  printer.drawLine();
  printer.alignCenter();
  printer.println(`*** ${printerLabel} ***`);
  printer.newLine();
  printer.newLine();
  printer.cut();

  await printer.execute();
}
